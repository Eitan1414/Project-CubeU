#include "cubeu/demo.hpp"
namespace cubeu {
uint32_t install_demo_program(Memory& m){
 const uint32_t e=0x80003100;
 // lis r4,0x8000; addi r3,0,40; addi r3,r3,2; stw r3,0x100(r4); blr
 const uint32_t code[]={0x3C808000,0x38600028,0x38630002,0x90640100,0x4E800020};
 for(unsigned i=0;i<5;i++) m.write32(e+i*4,code[i]);
 return e;
}
}
