#include "cubeu/memory.hpp"
#include <algorithm>
#include <stdexcept>

namespace cubeu {
namespace {
constexpr uint32_t MMIO_BASE=0xCC000000u;
constexpr uint32_t MMIO_SIZE=0x01000000u;
}
Memory::Memory() : data_(kSize, 0), mmio_(MMIO_SIZE,0) { clear(); }
void Memory::clear() {
    std::fill(data_.begin(), data_.end(), 0);
    std::fill(mmio_.begin(), mmio_.end(), 0);
    stats_={}; ticks_=0; fifo_bytes_.clear(); hardware_note_="MMIO GameCube de base actif";
    // Valeurs de statut sûres pour VI/PI/DI/AI/SI.
    mmio_[0x002000] = 0; // CP
    mmio_[0x003000] = 0; // PI
    mmio_[0x006000] = 0; // DI
}
bool Memory::is_mmio(uint32_t a){ return a>=MMIO_BASE && a<MMIO_BASE+MMIO_SIZE; }
uint32_t Memory::mmio_offset(uint32_t a){ return a-MMIO_BASE; }
bool Memory::valid(uint32_t a, std::size_t n) const {
    if(is_mmio(a)) return uint64_t(mmio_offset(a))+n<=mmio_.size();
    if (a < kBase) return false;
    const uint64_t off = static_cast<uint64_t>(a) - kBase;
    return off + n <= data_.size();
}
std::size_t Memory::offset(uint32_t a) const {
    if (a < kBase || uint64_t(a-kBase)>=data_.size()) throw std::out_of_range("GameCube address outside MEM1");
    return static_cast<std::size_t>(a-kBase);
}
uint8_t Memory::mmio_read8(uint32_t a){ stats_.mmio_reads++;stats_.last_mmio=a; return mmio_[mmio_offset(a)]; }
void Memory::mmio_write8(uint32_t a,uint8_t v){
    stats_.mmio_writes++;stats_.last_mmio=a; mmio_[mmio_offset(a)]=v;
    const uint32_t off=mmio_offset(a);
    if(off>=0x008000 && off<0x009000){stats_.fifo_writes++;stats_.last_fifo_word=(stats_.last_fifo_word<<8)|v; fifo_bytes_.push_back(v); if(fifo_bytes_.size()>1024*1024) fifo_bytes_.pop_front(); hardware_note_="Commandes FIFO Flipper reçues";}
    if(off>=0x006000 && off<0x006040){stats_.dvd_commands++;hardware_note_="Commande DVD détectée (HLE partiel)";}
}
uint8_t Memory::read8(uint32_t a){ if(is_mmio(a))return mmio_read8(a); return data_[offset(a)]; }
uint16_t Memory::read16(uint32_t a){ return (uint16_t(read8(a))<<8)|read8(a+1); }
uint32_t Memory::read32(uint32_t a){ return (uint32_t(read8(a))<<24)|(uint32_t(read8(a+1))<<16)|(uint32_t(read8(a+2))<<8)|read8(a+3); }
uint64_t Memory::read64(uint32_t a){ return (uint64_t(read32(a))<<32)|read32(a+4); }
void Memory::write8(uint32_t a,uint8_t v){ if(is_mmio(a)){mmio_write8(a,v);return;} data_[offset(a)]=v; }
void Memory::write16(uint32_t a,uint16_t v){write8(a,uint8_t(v>>8));write8(a+1,uint8_t(v));}
void Memory::write32(uint32_t a,uint32_t v){write8(a,uint8_t(v>>24));write8(a+1,uint8_t(v>>16));write8(a+2,uint8_t(v>>8));write8(a+3,uint8_t(v));}
void Memory::write64(uint32_t a,uint64_t v){write32(a,uint32_t(v>>32));write32(a+4,uint32_t(v));}
bool Memory::copy_in(uint32_t a,const uint8_t* d,std::size_t n){if(is_mmio(a)||!valid(a,n))return false;std::copy(d,d+n,data_.begin()+offset(a));return true;}
std::vector<uint8_t> Memory::take_fifo_bytes(std::size_t max_bytes){
    const std::size_t n=std::min(max_bytes,fifo_bytes_.size());
    std::vector<uint8_t> out; out.reserve(n);
    for(std::size_t i=0;i<n;++i){out.push_back(fifo_bytes_.front());fifo_bytes_.pop_front();}
    return out;
}
void Memory::tick(uint64_t cycles){
    ticks_+=cycles;
    // Time-base virtuel simplifié exposé via registres PI réservés au prototype.
    const uint32_t hi=uint32_t(ticks_>>32),lo=uint32_t(ticks_);
    for(int i=0;i<4;i++){mmio_[0x003100+i]=uint8_t(hi>>(24-i*8));mmio_[0x003104+i]=uint8_t(lo>>(24-i*8));}
}
}
