#include "cubeu/gpu.hpp"
#include "cubeu/memory.hpp"
#include <algorithm>
#include <cmath>

namespace cubeu {
SoftwareGpu::SoftwareGpu(Memory& memory) : memory_(memory), front_(kWidth*kHeight), back_(kWidth*kHeight) { reset(); }

void SoftwareGpu::reset() {
    std::fill(std::begin(bp_), std::end(bp_), 0);
    stats_ = {};
    frame_seed_ = 0;
    clear(0x10182000u);
    front_ = back_;
    status_ = "GPU logiciel initialise";
}

void SoftwareGpu::clear(uint32_t color) { std::fill(back_.begin(), back_.end(), color); }
void SoftwareGpu::pixel(int x,int y,uint32_t c){ if(x>=0&&x<kWidth&&y>=0&&y<kHeight) back_[y*kWidth+x]=c; }
void SoftwareGpu::line(int x0,int y0,int x1,int y1,uint32_t c){
    int dx=std::abs(x1-x0), sx=x0<x1?1:-1, dy=-std::abs(y1-y0), sy=y0<y1?1:-1, err=dx+dy;
    for(;;){pixel(x0,y0,c); if(x0==x1&&y0==y1)break; int e2=2*err; if(e2>=dy){err+=dy;x0+=sx;} if(e2<=dx){err+=dx;y0+=sy;}}
}
static int edge(int ax,int ay,int bx,int by,int px,int py){return (px-ax)*(by-ay)-(py-ay)*(bx-ax);} 
void SoftwareGpu::triangle(int x0,int y0,int x1,int y1,int x2,int y2,uint32_t c){
    int minx=std::max(0,std::min({x0,x1,x2})), maxx=std::min(kWidth-1,std::max({x0,x1,x2}));
    int miny=std::max(0,std::min({y0,y1,y2})), maxy=std::min(kHeight-1,std::max({y0,y1,y2}));
    for(int y=miny;y<=maxy;++y) for(int x=minx;x<=maxx;++x){int a=edge(x0,y0,x1,y1,x,y),b=edge(x1,y1,x2,y2,x,y),d=edge(x2,y2,x0,y0,x,y); if((a>=0&&b>=0&&d>=0)||(a<=0&&b<=0&&d<=0))pixel(x,y,c);} 
}

void SoftwareGpu::decode_command(const std::vector<uint8_t>& b,std::size_t& p){
    const uint8_t op=b[p++]; stats_.commands++;
    if(op==0x00) return;
    if(op==0x61 && p+4<=b.size()){
        uint32_t v=(uint32_t(b[p])<<24)|(uint32_t(b[p+1])<<16)|(uint32_t(b[p+2])<<8)|b[p+3]; p+=4;
        uint8_t reg=uint8_t(v>>24); bp_[reg]=v&0x00FFFFFFu; stats_.bp_loads++;
        if(reg==0x52 || reg==0x40){ uint32_t rgb=bp_[reg]&0x00FFFFFFu; clear((rgb<<8)|0x00u); status_="BP: couleur/framebuffer mis a jour"; }
        return;
    }
    if((op&0x80)==0x80){
        stats_.primitives++;
        // Sans état CP/XF complet, on consomme seulement le compteur de sommets si présent,
        // puis on matérialise l'activité FIFO par une primitive stable et animée.
        uint16_t count=0; if(p+2<=b.size()){count=(uint16_t(b[p])<<8)|b[p+1];p+=2;}
        frame_seed_ += 17u + count;
        int cx=160 + int((frame_seed_%61)-30), cy=120;
        uint32_t color=((0x30u+(frame_seed_&0x7Fu))<<24)|((0x70u+((frame_seed_>>2)&0x7Fu))<<16)|(0xD0u<<8);
        triangle(cx,35,cx-90,195,cx+90,195,color);
        line(cx,35,cx-90,195,0xFFFFFFFFu); line(cx-90,195,cx+90,195,0xFFFFFFFFu); line(cx+90,195,cx,35,0xFFFFFFFFu);
        status_="Primitive Flipper recue (rendu de compatibilite)";
        return;
    }
    // Commandes CP/XF fréquemment rencontrées : ignorer leur payload minimal lorsque connu.
    if(op==0x08 && p+5<=b.size()) { p+=5; return; }
    if(op==0x10 && p+5<=b.size()) { p+=5; return; }
    if(op==0x20 && p+5<=b.size()) { p+=5; return; }
    status_="Opcode FIFO non pris en charge";
}

void SoftwareGpu::process_fifo(std::size_t max_bytes){
    auto bytes=memory_.take_fifo_bytes(max_bytes);
    stats_.bytes_consumed += bytes.size();
    std::size_t p=0; while(p<bytes.size()) decode_command(bytes,p);
}
void SoftwareGpu::present(){ front_.swap(back_); back_=front_; stats_.frames++; }
}
