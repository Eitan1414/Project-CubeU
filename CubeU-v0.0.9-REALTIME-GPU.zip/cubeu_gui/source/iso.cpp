#include "cubeu/iso.hpp"
#include <array>
#include <cstdio>
#include <cstring>
#include <sys/stat.h>
#include <vector>

namespace cubeu { namespace {
uint32_t be32(const uint8_t* p){return(uint32_t(p[0])<<24)|(uint32_t(p[1])<<16)|(uint32_t(p[2])<<8)|p[3];}
std::string clean_text(const uint8_t* d,size_t n){std::string o;for(size_t i=0;i<n&&d[i];++i)o.push_back(d[i]>=32&&d[i]<127?char(d[i]):' ');while(!o.empty()&&o.back()==' ')o.pop_back();return o;}
bool seek_read(FILE* f,uint64_t off,void* out,size_t n){if(off>0x7fffffffULL)return false;if(fseek(f,long(off),SEEK_SET))return false;return fread(out,1,n,f)==n;}
bool parse_fst(FILE* f,IsoInfo& info){
 if(!info.fst_size||info.fst_size>16*1024*1024u)return false;std::vector<uint8_t> fst(info.fst_size);if(!seek_read(f,info.fst_offset,fst.data(),fst.size())||fst.size()<12)return false;
 uint32_t count=be32(fst.data()+8);if(!count||uint64_t(count)*12>fst.size())return false;info.fst_entries=count;info.fst_directories=0;info.fst_files=0;
 for(uint32_t i=0;i<count;i++){uint32_t typeName=be32(fst.data()+i*12);if(typeName&0x01000000u)info.fst_directories++;else info.fst_files++;}info.fst_valid=true;return true;
}
}
bool inspect_iso(const std::string& path,IsoInfo& info,std::string& error){
 info={};error.clear();struct stat st{};if(stat(path.c_str(),&st)==0)info.file_size=uint64_t(st.st_size);FILE* f=fopen(path.c_str(),"rb");if(!f){error="Impossible d'ouvrir l'ISO en lecture.";return false;}
 std::array<uint8_t,0x440> h{};if(!seek_read(f,0,h.data(),h.size())){fclose(f);error="ISO trop petit ou en-tete illisible.";return false;}
 info.game_id=clean_text(h.data(),6);info.title=clean_text(h.data()+0x20,64);info.dol_offset=be32(h.data()+0x420);info.fst_offset=be32(h.data()+0x424);info.fst_size=be32(h.data()+0x428);info.header_valid=be32(h.data()+0x1C)==0xC2339F3D&&info.game_id.size()>=4;
 if(!info.header_valid){fclose(f);error="En-tete GameCube invalide.";return false;}if(info.dol_offset<0x440||info.dol_offset>=info.file_size){fclose(f);error="Offset du DOL principal invalide.";return false;}
 if(uint64_t(info.fst_offset)+info.fst_size<=info.file_size)parse_fst(f,info);fclose(f);return true;
}
bool load_main_dol_from_iso(const std::string& path,Memory& memory,IsoInfo& info,std::string& error){
 if(!inspect_iso(path,info,error))return false;FILE* f=fopen(path.c_str(),"rb");if(!f){error="Impossible de rouvrir l'ISO.";return false;}std::array<uint8_t,0x100> h{};if(!seek_read(f,info.dol_offset,h.data(),h.size())){fclose(f);error="En-tete DOL illisible.";return false;}info.entry=be32(h.data()+0xE0);
 for(unsigned i=0;i<18;i++){bool text=i<7;unsigned j=text?i:i-7;uint32_t off=be32(h.data()+(text?0:0x1C)+j*4),addr=be32(h.data()+(text?0x48:0x64)+j*4),size=be32(h.data()+(text?0x90:0xAC)+j*4);if(!size)continue;if(uint64_t(info.dol_offset)+off+size>info.file_size){fclose(f);error="Section DOL hors ISO.";return false;}if(!memory.valid(addr,size)){fclose(f);error="Section DOL hors MEM1.";return false;}std::vector<uint8_t>d(size);if(!seek_read(f,uint64_t(info.dol_offset)+off,d.data(),size)){fclose(f);error="Lecture section DOL impossible.";return false;}memory.copy_in(addr,d.data(),size);info.sections_loaded++;info.bytes_loaded+=size;}
 uint32_t bss=be32(h.data()+0xD8),bs=be32(h.data()+0xDC);if(bs&&memory.valid(bss,bs))for(uint32_t i=0;i<bs;i++)memory.write8(bss+i,0);fclose(f);info.dol_loaded=true;return true;
}
}
