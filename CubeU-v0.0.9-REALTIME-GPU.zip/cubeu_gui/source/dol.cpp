#include "cubeu/dol.hpp"
#include <array>
#include <cstdio>
#include <vector>
namespace cubeu {
static uint32_t be32(const uint8_t* p){return(uint32_t(p[0])<<24)|(uint32_t(p[1])<<16)|(uint32_t(p[2])<<8)|p[3];}
bool load_dol(const std::string& path,Memory& m,DolInfo& out,std::string& err){
 FILE* f=std::fopen(path.c_str(),"rb");if(!f){err="Impossible d'ouvrir le DOL";return false;}
 std::array<uint8_t,0x100> h{};if(std::fread(h.data(),1,h.size(),f)!=h.size()){err="En-tete DOL incomplet";std::fclose(f);return false;}
 out={};out.entry=be32(&h[0xE0]);
 for(unsigned i=0;i<18;i++){
  uint32_t off=be32(&h[(i<7?0x00:0x1C)+(i<7?i:i-7)*4]);
  uint32_t addr=be32(&h[(i<7?0x48:0x64)+(i<7?i:i-7)*4]);
  uint32_t size=be32(&h[(i<7?0x90:0xAC)+(i<7?i:i-7)*4]);
  if(!size) continue;
  if(!m.valid(addr,size)){err="Section DOL hors des 24 Mio de MEM1";std::fclose(f);return false;}
  std::vector<uint8_t> data(size);if(std::fseek(f,long(off),SEEK_SET)||std::fread(data.data(),1,size,f)!=size){err="Lecture de section DOL impossible";std::fclose(f);return false;}
  m.copy_in(addr,data.data(),size);out.sections_loaded++;out.bytes_loaded+=size;
 }
 uint32_t bss=be32(&h[0xD8]),bss_size=be32(&h[0xDC]);if(bss_size&&m.valid(bss,bss_size))for(uint32_t i=0;i<bss_size;i++)m.write8(bss+i,0);
 std::fclose(f);return true;
}
}
