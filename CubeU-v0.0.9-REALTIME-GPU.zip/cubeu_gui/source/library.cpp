#include "cubeu/library.hpp"
#include <algorithm>
#include <cctype>
#include <cstdio>
#include <cstring>
#include <dirent.h>
#include <sys/stat.h>

namespace cubeu {
namespace {
bool has_game_extension(const std::string& path) {
    const auto dot = path.find_last_of('.');
    if (dot == std::string::npos) return false;
    std::string ext = path.substr(dot);
    std::transform(ext.begin(), ext.end(), ext.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return ext == ".iso" || ext == ".gcm";
}

std::string filename_without_extension(const std::string& path) {
    const auto slash = path.find_last_of("/\\");
    const auto start = slash == std::string::npos ? 0 : slash + 1;
    const auto dot = path.find_last_of('.');
    const auto end = dot == std::string::npos || dot < start ? path.size() : dot;
    return path.substr(start, end - start);
}

std::string clean_text(const char* data, std::size_t length) {
    std::string out;
    for (std::size_t i = 0; i < length && data[i] != '\0'; ++i) {
        const unsigned char c = static_cast<unsigned char>(data[i]);
        out.push_back((c >= 32 && c < 127) ? static_cast<char>(c) : ' ');
    }
    while (!out.empty() && out.back() == ' ') out.pop_back();
    return out;
}

std::string region_from_id(const std::string& id) {
    if (id.size() < 4) return "Inconnue";
    switch (id[3]) {
        case 'P': case 'D': case 'F': case 'I': case 'S': case 'H': case 'X': case 'Y': return "PAL";
        case 'E': return "NTSC-U";
        case 'J': return "NTSC-J";
        case 'K': return "NTSC-K";
        default: return "Inconnue";
    }
}
}

void GameLibrary::scan(const std::string& root) {
    games_.clear();
    message_.clear();
    scan_directory(root, 0);
    std::sort(games_.begin(), games_.end(), [](const GameEntry& a, const GameEntry& b) { return a.title < b.title; });
    if (games_.empty()) message_ = "Aucun jeu detecte dans SD:/games/.";
    else message_ = std::to_string(games_.size()) + (games_.size() == 1 ? " jeu detecte." : " jeux detectes.");
}

void GameLibrary::scan_directory(const std::string& directory, int depth) {
    if (depth > 4 || games_.size() >= 200) return;
    DIR* dir = opendir(directory.c_str());
    if (!dir) return;
    while (dirent* entry = readdir(dir)) {
        const std::string name = entry->d_name;
        if (name == "." || name == "..") continue;
        const std::string path = directory + "/" + name;
        struct stat st{};
        if (stat(path.c_str(), &st) != 0) continue;
        if (S_ISDIR(st.st_mode)) scan_directory(path, depth + 1);
        else if (S_ISREG(st.st_mode) && has_game_extension(path)) add_game(path);
        if (games_.size() >= 200) break;
    }
    closedir(dir);
}

void GameLibrary::add_game(const std::string& path) {
    GameEntry game;
    game.path = path;
    game.title = filename_without_extension(path);
    struct stat st{};
    if (stat(path.c_str(), &st) == 0) game.size_bytes = static_cast<std::uint64_t>(st.st_size);

    std::FILE* file = std::fopen(path.c_str(), "rb");
    if (file) {
        unsigned char header[0x60]{};
        const std::size_t read = std::fread(header, 1, sizeof(header), file);
        std::fclose(file);
        if (read >= 0x40) {
            game.game_id = clean_text(reinterpret_cast<const char*>(header), 6);
            const std::string disc_title = clean_text(reinterpret_cast<const char*>(header + 0x20), 64);
            if (!disc_title.empty()) game.title = disc_title;
            game.region = region_from_id(game.game_id);
            game.header_valid = game.game_id.size() >= 4;
        }
    }
    if (game.game_id.empty()) game.game_id = "------";
    if (game.region.empty()) game.region = "Inconnue";
    games_.push_back(std::move(game));
}
}
