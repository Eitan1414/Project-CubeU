#include "cubeu/cpu.hpp"
#include "cubeu/demo.hpp"
#include "cubeu/library.hpp"
#include "cubeu/memory.hpp"
#include "cubeu/iso.hpp"
#include "cubeu/gpu.hpp"

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <malloc.h>
#include <string>

#ifdef CUBEU_WIIU
#include <coreinit/cache.h>
#include <coreinit/screen.h>
#include <coreinit/thread.h>
#include <padscore/kpad.h>
#include <padscore/wpad.h>
#include <vpad/input.h>
#include <whb/proc.h>
#endif

using namespace cubeu;

#ifdef CUBEU_WIIU
namespace {
constexpr uint32_t BG = 0x14203300;
constexpr uint32_t PANEL = 0x23334D00;
constexpr uint32_t ACCENT = 0x3A78C200;
constexpr uint32_t ACCENT_DARK = 0x28548300;
constexpr uint32_t OK = 0x2B8A5A00;
constexpr uint32_t WARN = 0xA66A1F00;

constexpr int TV_W = 1280;
constexpr int TV_H = 720;
constexpr int DRC_W = 854;
constexpr int DRC_H = 480;

enum InputButton : uint32_t {
    INPUT_NONE  = 0,
    INPUT_UP    = 1u << 0,
    INPUT_DOWN  = 1u << 1,
    INPUT_A     = 1u << 2,
    INPUT_B     = 1u << 3,
    INPUT_X     = 1u << 4,
    INPUT_Y     = 1u << 5,
    INPUT_PLUS  = 1u << 6,
    INPUT_LEFT  = 1u << 7,
    INPUT_RIGHT = 1u << 8,
    INPUT_L     = 1u << 9,
    INPUT_R     = 1u << 10,
    INPUT_Z     = 1u << 11,
    INPUT_START = 1u << 12,
    INPUT_C_UP    = 1u << 13,
    INPUT_C_DOWN  = 1u << 14,
    INPUT_C_LEFT  = 1u << 15,
    INPUT_C_RIGHT = 1u << 16,
};

enum class Page { Home, Library, Details, IsoReader, Gameplay, Controller, About };

struct GameCubePadState {
    uint32_t buttons = 0;
    int8_t stickX = 0;
    int8_t stickY = 0;
    int8_t cStickX = 0;
    int8_t cStickY = 0;
    uint8_t triggerL = 0;
    uint8_t triggerR = 0;
};

struct ControllerState {
    bool gamepad = false;
    bool pro[4] = {false, false, false, false};
    GameCubePadState gc[4]{};
};

struct App {
    Memory memory;
    Cpu cpu;
    GameLibrary library;
    SoftwareGpu gpu;
    Page page = Page::Home;
    int selected = 0;
    int gameSelected = 0;
    std::string message = "Pret.";
    IsoInfo isoInfo{};
    std::string isoStatus = "Aucun ISO ouvert.";
    StepResult advancedResult = StepResult::Ok;
    bool realtimeRunning = false;
    uint64_t realtimeFrames = 0;
    uint32_t cpuBudgetPerFrame = 60000;

    App() : cpu(memory), gpu(memory) {
        memory.clear();
        cpu.reset(install_demo_program(memory));
        scan();
    }

    void scan() {
        library.scan("fs:/vol/external01/games");
        gameSelected = 0;
        message = library.message();
    }

    void selfTest() {
        memory.clear();
        cpu.reset(install_demo_program(memory));
        const auto result = cpu.run(20);
        message = (result == StepResult::Halted && memory.read32(0x80000100) == 42)
            ? "Test CPU reussi : 42."
            : "Echec du test CPU.";
    }

    bool hasSelectedGame() const {
        return !library.games().empty() && gameSelected >= 0 && gameSelected < static_cast<int>(library.games().size());
    }

    void openSelectedIso() {
        if (!hasSelectedGame()) { isoStatus = "Aucun jeu selectionne."; return; }
        std::string error;
        if (inspect_iso(library.games()[gameSelected].path, isoInfo, error)) {
            char text[160];
            std::snprintf(text, sizeof(text), "ISO ouvert : DOL @ %08X, FST @ %08X (%u octets).",
                          isoInfo.dol_offset, isoInfo.fst_offset, isoInfo.fst_size);
            isoStatus = text;
        } else {
            isoStatus = "Erreur ISO : " + error;
        }
        page = Page::IsoReader;
    }

    void startRealtimeSelected() {
        if (!hasSelectedGame()) { isoStatus = "Aucun jeu selectionne."; return; }
        memory.clear();
        gpu.reset();
        std::string error;
        if (!load_main_dol_from_iso(library.games()[gameSelected].path, memory, isoInfo, error)) {
            isoStatus = "Chargement temps reel impossible : " + error;
            page = Page::IsoReader;
            return;
        }
        cpu.reset(isoInfo.entry);
        realtimeRunning = true;
        realtimeFrames = 0;
        advancedResult = StepResult::Ok;
        isoStatus = "Execution temps reel demarree.";
        page = Page::Gameplay;
    }

    void runRealtimeFrame() {
        if (!realtimeRunning) return;
        for (uint32_t i = 0; i < cpuBudgetPerFrame; ++i) {
            advancedResult = cpu.step();
            if (advancedResult != StepResult::Ok) {
                realtimeRunning = false;
                isoStatus = "Execution arretee : " + cpu.error();
                break;
            }
        }
        gpu.process_fifo();
        gpu.present();
        ++realtimeFrames;
    }

    void advancedLaunchSelected() {
        if (!hasSelectedGame()) { isoStatus = "Aucun jeu selectionne."; return; }
        memory.clear();
        std::string error;
        if (!load_main_dol_from_iso(library.games()[gameSelected].path, memory, isoInfo, error)) {
            isoStatus = "Chargement avance impossible : " + error;
            page = Page::IsoReader;
            return;
        }
        cpu.reset(isoInfo.entry);
        advancedResult = cpu.run(2000000);
        char text[220];
        const char* result = advancedResult == StepResult::Ok ? "limite de securite atteinte" :
                             advancedResult == StepResult::Halted ? "programme arrete" :
                             advancedResult == StepResult::InvalidInstruction ? "instruction inconnue" : "faute memoire";
        std::snprintf(text, sizeof(text), "DOL charge : %u sections, %u octets. Entree %08X. Execution avancee : %s apres %llu instructions.",
                      isoInfo.sections_loaded, isoInfo.bytes_loaded, isoInfo.entry, result,
                      static_cast<unsigned long long>(cpu.state().instructions));
        isoStatus = text;
        if (!cpu.error().empty()) isoStatus += " Erreur : " + cpu.error();
        page = Page::IsoReader;
    }
};

uint32_t mapVpad(uint32_t b) {
    uint32_t r = 0;
    if (b & (VPAD_BUTTON_UP | VPAD_STICK_L_EMULATION_UP)) r |= INPUT_UP;
    if (b & (VPAD_BUTTON_DOWN | VPAD_STICK_L_EMULATION_DOWN)) r |= INPUT_DOWN;
    if (b & VPAD_BUTTON_A) r |= INPUT_A;
    if (b & VPAD_BUTTON_B) r |= INPUT_B;
    if (b & VPAD_BUTTON_X) r |= INPUT_X;
    if (b & VPAD_BUTTON_Y) r |= INPUT_Y;
    if (b & VPAD_BUTTON_PLUS) r |= INPUT_PLUS | INPUT_START;
    if (b & (VPAD_BUTTON_LEFT | VPAD_STICK_L_EMULATION_LEFT)) r |= INPUT_LEFT;
    if (b & (VPAD_BUTTON_RIGHT | VPAD_STICK_L_EMULATION_RIGHT)) r |= INPUT_RIGHT;
    if (b & (VPAD_BUTTON_L | VPAD_BUTTON_ZL)) r |= INPUT_L;
    if (b & VPAD_BUTTON_R) r |= INPUT_R;
    if (b & VPAD_BUTTON_ZR) r |= INPUT_Z;
    if (b & VPAD_STICK_R_EMULATION_UP) r |= INPUT_C_UP;
    if (b & VPAD_STICK_R_EMULATION_DOWN) r |= INPUT_C_DOWN;
    if (b & VPAD_STICK_R_EMULATION_LEFT) r |= INPUT_C_LEFT;
    if (b & VPAD_STICK_R_EMULATION_RIGHT) r |= INPUT_C_RIGHT;
    return r;
}

uint32_t mapPro(uint32_t b) {
    uint32_t r = 0;
    if (b & (WPAD_PRO_BUTTON_UP | WPAD_PRO_STICK_L_EMULATION_UP)) r |= INPUT_UP;
    if (b & (WPAD_PRO_BUTTON_DOWN | WPAD_PRO_STICK_L_EMULATION_DOWN)) r |= INPUT_DOWN;
    if (b & WPAD_PRO_BUTTON_A) r |= INPUT_A;
    if (b & WPAD_PRO_BUTTON_B) r |= INPUT_B;
    if (b & WPAD_PRO_BUTTON_X) r |= INPUT_X;
    if (b & WPAD_PRO_BUTTON_Y) r |= INPUT_Y;
    if (b & WPAD_PRO_BUTTON_PLUS) r |= INPUT_PLUS | INPUT_START;
    if (b & (WPAD_PRO_BUTTON_LEFT | WPAD_PRO_STICK_L_EMULATION_LEFT)) r |= INPUT_LEFT;
    if (b & (WPAD_PRO_BUTTON_RIGHT | WPAD_PRO_STICK_L_EMULATION_RIGHT)) r |= INPUT_RIGHT;
    if (b & (WPAD_PRO_BUTTON_L | WPAD_PRO_BUTTON_ZL)) r |= INPUT_L;
    if (b & WPAD_PRO_BUTTON_R) r |= INPUT_R;
    if (b & WPAD_PRO_BUTTON_ZR) r |= INPUT_Z;
    if (b & WPAD_PRO_STICK_R_EMULATION_UP) r |= INPUT_C_UP;
    if (b & WPAD_PRO_STICK_R_EMULATION_DOWN) r |= INPUT_C_DOWN;
    if (b & WPAD_PRO_STICK_R_EMULATION_LEFT) r |= INPUT_C_LEFT;
    if (b & WPAD_PRO_STICK_R_EMULATION_RIGHT) r |= INPUT_C_RIGHT;
    return r;
}

void updateVirtualGcPad(GameCubePadState& pad, uint32_t mapped) {
    pad.buttons = mapped;
    pad.stickX = (mapped & INPUT_LEFT) ? -100 : ((mapped & INPUT_RIGHT) ? 100 : 0);
    pad.stickY = (mapped & INPUT_UP) ? 100 : ((mapped & INPUT_DOWN) ? -100 : 0);
    pad.cStickX = (mapped & INPUT_C_LEFT) ? -100 : ((mapped & INPUT_C_RIGHT) ? 100 : 0);
    pad.cStickY = (mapped & INPUT_C_UP) ? 100 : ((mapped & INPUT_C_DOWN) ? -100 : 0);
    pad.triggerL = (mapped & INPUT_L) ? 255 : 0;
    pad.triggerR = (mapped & INPUT_R) ? 255 : 0;
}

uint32_t readInput(ControllerState& state) {
    uint32_t pressed = 0;
    state.gamepad = false;
    for (bool& v : state.pro) v = false;

    VPADStatus vpad{};
    VPADReadError vpadError = VPAD_READ_NO_SAMPLES;
    const int32_t vpadCount = VPADRead(VPAD_CHAN_0, &vpad, 1, &vpadError);
    if (vpadCount > 0 && vpadError == VPAD_READ_SUCCESS) {
        state.gamepad = true;
        const uint32_t mapped = mapVpad(vpad.trigger | vpad.hold);
        pressed |= mapVpad(vpad.trigger);
        updateVirtualGcPad(state.gc[0], mapped);
    }

    for (int ch = 0; ch < 4; ++ch) {
        KPADStatus status{};
        KPADError error = KPAD_ERROR_NO_SAMPLES;
        const uint32_t count = KPADReadEx(static_cast<KPADChan>(ch), &status, 1, &error);
        if (count == 0 || error != KPAD_ERROR_OK) continue;
        if (status.extensionType != WPAD_EXT_PRO_CONTROLLER) continue;
        state.pro[ch] = true;
        const uint32_t mapped = mapPro(status.pro.trigger | status.pro.hold);
        pressed |= mapPro(status.pro.trigger);
        updateVirtualGcPad(state.gc[ch], mapped);
    }
    return pressed;
}

void rect(OSScreenID screen, int x, int y, int w, int h, uint32_t color) {
    for (int yy = y; yy < y + h; ++yy)
        for (int xx = x; xx < x + w; ++xx)
            OSScreenPutPixelEx(screen, xx, yy, color);
}

void text(OSScreenID screen, int col, int row, const std::string& s) {
    OSScreenPutFontEx(screen, col, row, s.c_str());
}

void drawHeader(OSScreenID screen, int width, const char* subtitle) {
    rect(screen, 0, 0, width, 74, ACCENT_DARK);
    text(screen, 3, 1, "CubeU");
    text(screen, 3, 3, subtitle);
    text(screen, width > 900 ? 126 : 82, 1, "v0.0.9");
}

void drawMenu(OSScreenID screen, int width, int height, App& app, const ControllerState& pads) {
    OSScreenClearBufferEx(screen, BG);
    drawHeader(screen, width, "Emulateur GameCube natif experimental");

    const char* items[] = {"Jeux", "Actualiser les jeux", "Manettes", "A propos", "Quitter"};
    const int startY = screen == SCREEN_TV ? 145 : 105;
    const int boxW = screen == SCREEN_TV ? 720 : 540;
    const int boxH = screen == SCREEN_TV ? 66 : 50;
    const int gap = screen == SCREEN_TV ? 78 : 58;
    const int x = screen == SCREEN_TV ? 80 : 45;

    for (int i = 0; i < 5; ++i) {
        rect(screen, x, startY + i * gap, boxW, boxH, i == app.selected ? ACCENT : PANEL);
        text(screen, screen == SCREEN_TV ? 8 : 5, (startY + i * gap) / 24 + 1,
             std::string(i == app.selected ? ">  " : "   ") + items[i]);
    }

    const int infoX = screen == SCREEN_TV ? 860 : 620;
    const int infoY = screen == SCREEN_TV ? 145 : 105;
    const int infoW = width - infoX - 35;
    rect(screen, infoX, infoY, infoW, screen == SCREEN_TV ? 310 : 220, PANEL);
    text(screen, screen == SCREEN_TV ? 87 : 64, infoY / 24 + 1, "Etat");
    text(screen, screen == SCREEN_TV ? 87 : 64, infoY / 24 + 3,
         "Jeux : " + std::to_string(app.library.games().size()));
    text(screen, screen == SCREEN_TV ? 87 : 64, infoY / 24 + 5,
         std::string("GamePad : ") + (pads.gamepad ? "connecte" : "non detecte"));

    int proCount = 0;
    for (bool p : pads.pro) if (p) ++proCount;
    text(screen, screen == SCREEN_TV ? 87 : 64, infoY / 24 + 7,
         "Pro Controller : " + std::to_string(proCount));

    rect(screen, 0, height - 54, width, 54, ACCENT_DARK);
    text(screen, 3, height / 24 - 2, "Haut/Bas : choisir     A : valider     B : retour     + : quitter");
}

void drawLibrary(OSScreenID screen, int width, int height, App& app) {
    OSScreenClearBufferEx(screen, BG);
    drawHeader(screen, width, "Bibliotheque de jeux");
    const auto& games = app.library.games();
    if (games.empty()) {
        rect(screen, 55, 120, width - 110, 200, PANEL);
        text(screen, 6, 6, "Aucun jeu detecte.");
        text(screen, 6, 9, "Place les fichiers .iso ou .gcm dans SD:/games/");
        text(screen, 6, 12, "X : relancer la recherche");
    } else {
        const int first = app.gameSelected > 5 ? app.gameSelected - 5 : 0;
        const int last = std::min(first + 9, static_cast<int>(games.size()));
        int y = 105;
        for (int i = first; i < last; ++i, y += 58) {
            rect(screen, 50, y, width - 100, 48, i == app.gameSelected ? ACCENT : PANEL);
            text(screen, 6, y / 24 + 1, std::string(i == app.gameSelected ? ">  " : "   ") + games[i].title);
        }
    }
    rect(screen, 0, height - 54, width, 54, ACCENT_DARK);
    text(screen, 3, height / 24 - 2, "A : details     X : actualiser     B : menu");
}

void drawDetails(OSScreenID screen, int width, int height, App& app) {
    OSScreenClearBufferEx(screen, BG);
    drawHeader(screen, width, "Informations du jeu");
    rect(screen, 55, 115, width - 110, height - 200, PANEL);
    const auto& games = app.library.games();
    if (!games.empty()) {
        const auto& g = games[app.gameSelected];
        text(screen, 7, 6, "Titre  : " + g.title);
        text(screen, 7, 9, "ID     : " + g.game_id);
        text(screen, 7, 12, "Region : " + g.region);
        char size[64];
        std::snprintf(size, sizeof(size), "Taille : %.2f Gio", static_cast<double>(g.size_bytes) / 1073741824.0);
        text(screen, 7, 15, size);
        text(screen, 7, 19, "A : ouvrir et lire l'ISO");
        text(screen, 7, 22, "Y : execution temps reel + GPU logiciel experimental");
    }
    rect(screen, 0, height - 54, width, 54, ACCENT_DARK);
    text(screen, 3, height / 24 - 2, "A : lire ISO     Y : lancer en temps reel     B : bibliotheque");
}

void drawIsoReader(OSScreenID screen, int width, int height, App& app) {
    OSScreenClearBufferEx(screen, BG);
    drawHeader(screen, width, "Demarrage GameCube experimental");
    rect(screen, 45, 100, width - 90, height - 180, PANEL);
    text(screen, 6, 5, "Fichier ouvert en lecture seule.");
    text(screen, 6, 8, "ID       : " + (app.isoInfo.game_id.empty() ? std::string("------") : app.isoInfo.game_id));
    text(screen, 6, 11, "Titre    : " + (app.isoInfo.title.empty() ? std::string("Inconnu") : app.isoInfo.title));
    char line[160];
    std::snprintf(line, sizeof(line), "DOL      : offset %08X, entree %08X", app.isoInfo.dol_offset, app.isoInfo.entry);
    text(screen, 6, 14, line);
    std::snprintf(line, sizeof(line), "FST      : offset %08X, taille %u", app.isoInfo.fst_offset, app.isoInfo.fst_size);
    text(screen, 6, 17, line);
    std::snprintf(line, sizeof(line), "Contenu  : %u fichiers, %u dossiers", app.isoInfo.fst_files, app.isoInfo.fst_directories);
    text(screen, 6, 19, line);
    text(screen, 6, 22, app.isoStatus);
    const auto& hw=app.memory.hardware_stats();
    std::snprintf(line,sizeof(line),"MMIO : %llu lectures, %llu ecritures, FIFO %llu, DVD %llu",
      (unsigned long long)hw.mmio_reads,(unsigned long long)hw.mmio_writes,
      (unsigned long long)hw.fifo_writes,(unsigned long long)hw.dvd_commands);
    text(screen,6,24,line);
    text(screen, 6, 25, "CPU et chargeur avances actifs. MMIO, timers, FPU et paired singles partiels actifs. GPU/DSP complets restent a implementer.");
    rect(screen, 0, height - 54, width, 54, ACCENT_DARK);
    text(screen, 3, height / 24 - 2, "Y : relancer le demarrage     B : revenir");
}

void drawGameplay(OSScreenID screen, int width, int height, App& app) {
    OSScreenClearBufferEx(screen, 0x080C1200);
    drawHeader(screen, width, "Execution temps reel / GPU logiciel");
    const auto& fb=app.gpu.framebuffer();
    const int scale = screen == SCREEN_TV ? 2 : 1;
    const int viewW = SoftwareGpu::kWidth * scale;
    const int viewH = SoftwareGpu::kHeight * scale;
    const int ox = (width-viewW)/2;
    const int oy = screen == SCREEN_TV ? 105 : 92;
    for(int y=0;y<SoftwareGpu::kHeight;++y){
        for(int x=0;x<SoftwareGpu::kWidth;++x){
            uint32_t c=fb[y*SoftwareGpu::kWidth+x];
            if(scale==1) OSScreenPutPixelEx(screen,ox+x,oy+y,c);
            else { int px=ox+x*2,py=oy+y*2; OSScreenPutPixelEx(screen,px,py,c); OSScreenPutPixelEx(screen,px+1,py,c); OSScreenPutPixelEx(screen,px,py+1,c); OSScreenPutPixelEx(screen,px+1,py+1,c); }
        }
    }
    const auto& gs=app.gpu.stats();
    char line[180];
    std::snprintf(line,sizeof(line),"CPU %llu instr. | frames %llu | FIFO %llu octets | primitives %llu",
      (unsigned long long)app.cpu.state().instructions,(unsigned long long)app.realtimeFrames,
      (unsigned long long)gs.bytes_consumed,(unsigned long long)gs.primitives);
    text(screen,3,height/24-4,line);
    text(screen,3,height/24-3,app.gpu.status());
    text(screen,3,height/24-2,app.realtimeRunning ? "B : arreter et revenir" : "Execution arretee - B : revenir");
}

void drawController(OSScreenID screen, int width, int height, const ControllerState& pads) {
    OSScreenClearBufferEx(screen, BG);
    drawHeader(screen, width, "Configuration des manettes");
    rect(screen, 55, 110, width - 110, height - 190, PANEL);

    text(screen, 7, 6, std::string("GamePad : ") + (pads.gamepad ? "CONNECTE" : "NON DETECTE"));
    int row = 9;
    for (int i = 0; i < 4; ++i, row += 3) {
        text(screen, 7, row, "Wii U Pro " + std::to_string(i + 1) + " : " + (pads.pro[i] ? "CONNECTEE" : "non detectee"));
    }
    text(screen, 7, row + 2, "Mapping GameCube : A/B/X/Y identiques, + = Start, ZR = Z,");
    text(screen, 7, row + 4, "L ou ZL = L, R = R, stick gauche = stick GC,");
    text(screen, 7, row + 6, "stick droit = C-stick, croix = croix GameCube.");
    text(screen, 7, row + 8, "Important : CubeU ne peut pas appairer une nouvelle manette.");
    text(screen, 7, row + 10, "Appaire-la dans le menu Wii U, puis relance CubeU.");

    rect(screen, 0, height - 54, width, 54, ACCENT_DARK);
    text(screen, 3, height / 24 - 2, "B : retour");
}

void drawAbout(OSScreenID screen, int width, int height, App& app) {
    OSScreenClearBufferEx(screen, BG);
    drawHeader(screen, width, "A propos");
    rect(screen, 55, 110, width - 110, height - 190, PANEL);
    text(screen, 7, 6, "CubeU est une application Wii U native, pas un plugin WUPS.");
    text(screen, 7, 9, "Cette version propose une interface graphique et detecte les jeux.");
    text(screen, 7, 12, "Demarrage experimental et pont de manettes GameCube actifs.");
    text(screen, 7, 16, "Y : lancer le test CPU interne");
    text(screen, 7, 19, app.message);
    rect(screen, 0, height - 54, width, 54, ACCENT_DARK);
    text(screen, 3, height / 24 - 2, "Y : test CPU     B : retour");
}

void draw(OSScreenID screen, int width, int height, App& app, const ControllerState& pads) {
    switch (app.page) {
        case Page::Home: drawMenu(screen, width, height, app, pads); break;
        case Page::Library: drawLibrary(screen, width, height, app); break;
        case Page::Details: drawDetails(screen, width, height, app); break;
        case Page::IsoReader: drawIsoReader(screen, width, height, app); break;
        case Page::Gameplay: drawGameplay(screen, width, height, app); break;
        case Page::Controller: drawController(screen, width, height, pads); break;
        case Page::About: drawAbout(screen, width, height, app); break;
    }
}
}

int main(int, char**) {
    WHBProcInit();
    KPADInit();
    OSScreenInit();

    const size_t tvSize = OSScreenGetBufferSizeEx(SCREEN_TV);
    const size_t drcSize = OSScreenGetBufferSizeEx(SCREEN_DRC);
    void* tvBuffer = memalign(0x100, tvSize);
    void* drcBuffer = memalign(0x100, drcSize);
    if (!tvBuffer || !drcBuffer) {
        if (tvBuffer) free(tvBuffer);
        if (drcBuffer) free(drcBuffer);
        WHBProcShutdown();
        return 1;
    }

    OSScreenSetBufferEx(SCREEN_TV, tvBuffer);
    OSScreenSetBufferEx(SCREEN_DRC, drcBuffer);
    OSScreenEnableEx(SCREEN_TV, true);
    OSScreenEnableEx(SCREEN_DRC, true);

    App app;
    ControllerState pads;
    bool quit = false;

    while (WHBProcIsRunning() && !quit) {
        const uint32_t pressed = readInput(pads);
        if (pressed & INPUT_PLUS) quit = true;

        if (app.page == Page::Home) {
            if (pressed & INPUT_UP) app.selected = (app.selected + 4) % 5;
            if (pressed & INPUT_DOWN) app.selected = (app.selected + 1) % 5;
            if (pressed & INPUT_A) {
                if (app.selected == 0) app.page = Page::Library;
                else if (app.selected == 1) app.scan();
                else if (app.selected == 2) app.page = Page::Controller;
                else if (app.selected == 3) app.page = Page::About;
                else quit = true;
            }
        } else if (app.page == Page::Library) {
            const int count = static_cast<int>(app.library.games().size());
            if (count > 0 && (pressed & INPUT_UP)) app.gameSelected = (app.gameSelected + count - 1) % count;
            if (count > 0 && (pressed & INPUT_DOWN)) app.gameSelected = (app.gameSelected + 1) % count;
            if (count > 0 && (pressed & INPUT_A)) app.page = Page::Details;
            if (pressed & INPUT_X) app.scan();
            if (pressed & INPUT_B) app.page = Page::Home;
        } else if (app.page == Page::Details) {
            if (pressed & INPUT_A) app.openSelectedIso();
            if (pressed & INPUT_Y) app.startRealtimeSelected();
            if (pressed & INPUT_B) app.page = Page::Library;
        } else if (app.page == Page::IsoReader) {
            if (pressed & INPUT_Y) app.startRealtimeSelected();
            if (pressed & INPUT_B) app.page = Page::Details;
        } else if (app.page == Page::Gameplay) {
            app.runRealtimeFrame();
            if (pressed & INPUT_B) { app.realtimeRunning=false; app.page=Page::Details; }
        } else if (app.page == Page::Controller) {
            if (pressed & INPUT_B) app.page = Page::Home;
        } else if (app.page == Page::About) {
            if (pressed & INPUT_Y) app.selfTest();
            if (pressed & INPUT_B) app.page = Page::Home;
        }

        draw(SCREEN_TV, TV_W, TV_H, app, pads);
        draw(SCREEN_DRC, DRC_W, DRC_H, app, pads);
        DCFlushRange(tvBuffer, tvSize);
        DCFlushRange(drcBuffer, drcSize);
        OSScreenFlipBuffersEx(SCREEN_TV);
        OSScreenFlipBuffersEx(SCREEN_DRC);
        OSSleepTicks(OSMillisecondsToTicks(16));
    }

    OSScreenEnableEx(SCREEN_TV, false);
    OSScreenEnableEx(SCREEN_DRC, false);
    free(tvBuffer);
    free(drcBuffer);
    WHBProcShutdown();
    return 0;
}
#else
int main() {
    Memory memory;
    Cpu cpu(memory);
    memory.clear();
    cpu.reset(install_demo_program(memory));
    cpu.run(20);
    return memory.read32(0x80000100) == 42 ? 0 : 1;
}
#endif
