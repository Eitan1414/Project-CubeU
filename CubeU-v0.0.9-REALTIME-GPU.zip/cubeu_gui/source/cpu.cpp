#include "cubeu/cpu.hpp"
#include <cstdio>
#include <exception>
#include <cstring>
#include <cmath>

namespace cubeu {
Cpu::Cpu(Memory& m):mem_(m){}
void Cpu::reset(uint32_t e){
 state_={}; state_.pc=e; state_.gpr[1]=0x817FF000u; state_.gpr[13]=0x80003000u;
 state_.msr=0x00002030u; halted_=false; error_.clear();
}
int32_t Cpu::sign_extend(uint32_t v,unsigned b){const uint32_t m=1u<<(b-1);return static_cast<int32_t>((v^m)-m);}
uint32_t Cpu::rotl32(uint32_t v,unsigned s){s&=31;return s?((v<<s)|(v>>(32-s))):v;}
uint32_t Cpu::mask32(unsigned mb,unsigned me){
 uint32_t m=0; for(unsigned i=0;i<32;i++){bool on=mb<=me?(i>=mb&&i<=me):(i>=mb||i<=me);if(on)m|=1u<<(31-i);} return m;
}
void Cpu::set_cr_field(unsigned f,int32_t a,int32_t b,bool logical){
 uint32_t bits= logical ? (uint32_t(a)<uint32_t(b)?8:(uint32_t(a)>uint32_t(b)?4:2)) : (a<b?8:(a>b?4:2));
 if(state_.xer&0x80000000u) bits|=1; const unsigned shift=28-(f&7)*4; state_.cr=(state_.cr&~(0xFu<<shift))|(bits<<shift);
}
void Cpu::set_cr0(uint32_t v){set_cr_field(0,static_cast<int32_t>(v),0,false);}
uint32_t Cpu::read_spr(uint32_t spr) const {if(spr==1)return state_.xer;if(spr==8)return state_.lr;if(spr==9)return state_.ctr;if(spr==268)return uint32_t(state_.time_base);if(spr==269)return uint32_t(state_.time_base>>32);return 0;}
void Cpu::write_spr(uint32_t spr,uint32_t v){if(spr==1)state_.xer=v;else if(spr==8)state_.lr=v;else if(spr==9)state_.ctr=v;}
StepResult Cpu::step(){
 if(halted_) return StepResult::Halted;
 try {
  const uint32_t pc=state_.pc, ins=mem_.read32(pc), op=ins>>26; state_.pc+=4; state_.instructions++; state_.time_base+=12; mem_.tick(12);
  const uint32_t rd=(ins>>21)&31, ra=(ins>>16)&31, rb=(ins>>11)&31; const int32_t simm=sign_extend(ins&0xFFFF,16);
  auto ea=[&](bool update=false){uint32_t a=(ra?state_.gpr[ra]:0)+simm;if(update&&ra)state_.gpr[ra]=a;return a;};
  switch(op){
   case 4:{ // Paired singles subset (ps_add/sub/mul/madd/merge)
    const uint32_t xo=(ins>>1)&0x1F; const uint32_t frd=rd,fra=ra,frb=rb,frc=(ins>>6)&31;
    if(xo==21) state_.fpr[frd]=state_.fpr[fra]+state_.fpr[frb];
    else if(xo==20) state_.fpr[frd]=state_.fpr[fra]-state_.fpr[frb];
    else if(xo==25) state_.fpr[frd]=state_.fpr[fra]*state_.fpr[frc];
    else if(xo==29) state_.fpr[frd]=state_.fpr[fra]*state_.fpr[frc]+state_.fpr[frb];
    else if(xo==6||xo==7||xo==10||xo==11) state_.fpr[frd]=(xo==6||xo==10)?state_.fpr[fra]:state_.fpr[frb];
    else {char b[96];std::snprintf(b,sizeof b,"Unknown paired-single XO %u at %08X",xo,pc);error_=b;return StepResult::InvalidInstruction;}
    break;}
   case 7: state_.gpr[rd]=uint32_t(int32_t(state_.gpr[ra])*simm); break; // mulli
   case 8:{uint32_t a=uint32_t(simm)-state_.gpr[ra];state_.gpr[rd]=a;break;} // subfic
   case 10: set_cr_field((ins>>23)&7,int32_t(state_.gpr[ra]),int32_t(ins&0xFFFF),true); break;
   case 11: set_cr_field((ins>>23)&7,int32_t(state_.gpr[ra]),simm,false); break;
   case 12: case 13:{state_.gpr[rd]=state_.gpr[ra]+simm;if(op==13)set_cr0(state_.gpr[rd]);break;}
   case 14: state_.gpr[rd]=(ra?state_.gpr[ra]:0)+simm; break;
   case 15: state_.gpr[rd]=(ra?state_.gpr[ra]:0)+uint32_t(simm<<16); break;
   case 16:{int32_t bd=sign_extend(ins&0xFFFC,16);uint32_t bo=(ins>>21)&31,bi=(ins>>16)&31;bool co=true,cc=true;if(!(bo&4)){state_.ctr--;co=((state_.ctr!=0)^bool(bo&2));}if(!(bo&16)){bool bit=(state_.cr>>(31-bi))&1;cc=(bit==bool(bo&8));}if(co&&cc){if(ins&1)state_.lr=state_.pc;state_.pc=(ins&2)?uint32_t(bd):pc+bd;}break;}
   case 18:{int32_t li=sign_extend(ins&0x03FFFFFC,26);if(ins&1)state_.lr=state_.pc;state_.pc=(ins&2)?uint32_t(li):pc+li;break;}
   case 19:{uint32_t xo=(ins>>1)&0x3FF;if(xo==16){if(ins&1)state_.lr=state_.pc;state_.pc=state_.lr&~3u;if(!state_.pc){halted_=true;return StepResult::Halted;}}else if(xo==528){if(ins&1)state_.lr=state_.pc;state_.pc=state_.ctr&~3u;}else if(xo==0){uint32_t bf=(ins>>23)&7,bfa=(ins>>18)&7;uint32_t sh=28-bf*4,sha=28-bfa*4;state_.cr=(state_.cr&~(0xFu<<sh))|(((state_.cr>>sha)&0xF)<<sh);}else{error_="Unknown opcode 19";return StepResult::InvalidInstruction;}break;}
   case 20: case 21: case 23:{unsigned sh=op==23?(state_.gpr[rb]&31):((ins>>11)&31),mb=(ins>>6)&31,me=(ins>>1)&31;uint32_t v=rotl32(state_.gpr[rd],sh),m=mask32(mb,me);if(op==20)state_.gpr[ra]=(state_.gpr[ra]&~m)|(v&m);else state_.gpr[ra]=v&m;if(ins&1)set_cr0(state_.gpr[ra]);break;}
   case 24: state_.gpr[ra]=state_.gpr[rd]|(ins&0xFFFF); break;
   case 25: state_.gpr[ra]=state_.gpr[rd]|((ins&0xFFFF)<<16); break;
   case 26: state_.gpr[ra]=state_.gpr[rd]^(ins&0xFFFF); break;
   case 27: state_.gpr[ra]=state_.gpr[rd]^((ins&0xFFFF)<<16); break;
   case 28: state_.gpr[ra]=state_.gpr[rd]&(ins&0xFFFF);set_cr0(state_.gpr[ra]);break;
   case 29: state_.gpr[ra]=state_.gpr[rd]&((ins&0xFFFF)<<16);set_cr0(state_.gpr[ra]);break;
   case 32: state_.gpr[rd]=mem_.read32(ea());break; case 33:state_.gpr[rd]=mem_.read32(ea(true));break;
   case 34: state_.gpr[rd]=mem_.read8(ea());break; case 35:state_.gpr[rd]=mem_.read8(ea(true));break;
   case 36: mem_.write32(ea(),state_.gpr[rd]);break; case 37:mem_.write32(ea(true),state_.gpr[rd]);break;
   case 38: mem_.write8(ea(),uint8_t(state_.gpr[rd]));break; case 39:mem_.write8(ea(true),uint8_t(state_.gpr[rd]));break;
   case 40: state_.gpr[rd]=mem_.read16(ea());break; case 41:state_.gpr[rd]=mem_.read16(ea(true));break;
   case 42: state_.gpr[rd]=uint32_t(int32_t(int16_t(mem_.read16(ea()))));break; case 43:state_.gpr[rd]=uint32_t(int32_t(int16_t(mem_.read16(ea(true)))));break;
   case 44: mem_.write16(ea(),uint16_t(state_.gpr[rd]));break; case 45:mem_.write16(ea(true),uint16_t(state_.gpr[rd]));break;
   case 48: case 49:{uint32_t bits=mem_.read32(ea(op==49));float f;std::memcpy(&f,&bits,4);state_.fpr[rd]=f;break;}
   case 50: case 51:{uint64_t bits=mem_.read64(ea(op==51));double d;std::memcpy(&d,&bits,8);state_.fpr[rd]=d;break;}
   case 52: case 53:{float f=float(state_.fpr[rd]);uint32_t bits;std::memcpy(&bits,&f,4);mem_.write32(ea(op==53),bits);break;}
   case 54: case 55:{uint64_t bits;double d=state_.fpr[rd];std::memcpy(&bits,&d,8);mem_.write64(ea(op==55),bits);break;}
   case 59:{uint32_t xo=(ins>>1)&31;uint32_t frc=(ins>>6)&31;if(xo==18)state_.fpr[rd]=state_.fpr[ra]/state_.fpr[rb];else if(xo==20)state_.fpr[rd]=state_.fpr[ra]-state_.fpr[rb];else if(xo==21)state_.fpr[rd]=state_.fpr[ra]+state_.fpr[rb];else if(xo==25)state_.fpr[rd]=state_.fpr[ra]*state_.fpr[frc];else {error_="Unknown single-float opcode";return StepResult::InvalidInstruction;}break;}
   case 63:{uint32_t xo=(ins>>1)&0x3FF;uint32_t frc=(ins>>6)&31;if(xo==18)state_.fpr[rd]=state_.fpr[ra]/state_.fpr[rb];else if(xo==20)state_.fpr[rd]=state_.fpr[ra]-state_.fpr[rb];else if(xo==21)state_.fpr[rd]=state_.fpr[ra]+state_.fpr[rb];else if((xo&31)==25)state_.fpr[rd]=state_.fpr[ra]*state_.fpr[frc];else if(xo==72)state_.fpr[rd]=state_.fpr[rb];else if(xo==40)state_.fpr[rd]=-state_.fpr[rb];else if(xo==264)state_.fpr[rd]=std::fabs(state_.fpr[rb]);else {error_="Unknown double-float opcode";return StepResult::InvalidInstruction;}break;}
   case 46:{uint32_t a=ea();for(uint32_t r=rd;r<32;r++,a+=4)state_.gpr[r]=mem_.read32(a);break;}
   case 47:{uint32_t a=ea();for(uint32_t r=rd;r<32;r++,a+=4)mem_.write32(a,state_.gpr[r]);break;}
   case 31:{uint32_t xo=(ins>>1)&0x3FF;bool rc=ins&1;
    if(xo==0||xo==32)set_cr_field((ins>>23)&7,int32_t(state_.gpr[ra]),int32_t(state_.gpr[rb]),xo==32);
    else if(xo==19)state_.gpr[rd]=state_.cr;
    else if(xo==28)state_.gpr[ra]=state_.gpr[rd]&state_.gpr[rb];
    else if(xo==40)state_.gpr[rd]=state_.gpr[rb]-state_.gpr[ra];
    else if(xo==124)state_.gpr[ra]=~(state_.gpr[rd]|state_.gpr[rb]);
    else if(xo==266)state_.gpr[rd]=state_.gpr[ra]+state_.gpr[rb];
    else if(xo==316)state_.gpr[ra]=state_.gpr[rd]^state_.gpr[rb];
    else if(xo==444)state_.gpr[ra]=state_.gpr[rd]|state_.gpr[rb];
    else if(xo==24)state_.gpr[ra]=state_.gpr[rd]<<(state_.gpr[rb]&31);
    else if(xo==536)state_.gpr[ra]=state_.gpr[rd]>>(state_.gpr[rb]&31);
    else if(xo==824)state_.gpr[ra]=uint32_t(int32_t(state_.gpr[rd])>>((ins>>11)&31));
    else if(xo==922)state_.gpr[ra]=uint32_t(int32_t(int16_t(state_.gpr[rd])));
    else if(xo==954)state_.gpr[ra]=uint32_t(int32_t(int8_t(state_.gpr[rd])));
    else if(xo==339){uint32_t spr=((ins>>16)&0x1F)<<5|((ins>>11)&0x1F);state_.gpr[rd]=read_spr(spr);}
    else if(xo==467){uint32_t spr=((ins>>16)&0x1F)<<5|((ins>>11)&0x1F);write_spr(spr,state_.gpr[rd]);}
    else if(xo==23)state_.gpr[rd]=mem_.read32(state_.gpr[ra]+state_.gpr[rb]);
    else if(xo==87)state_.gpr[rd]=mem_.read8(state_.gpr[ra]+state_.gpr[rb]);
    else if(xo==151)mem_.write32(state_.gpr[ra]+state_.gpr[rb],state_.gpr[rd]);
    else if(xo==215)mem_.write8(state_.gpr[ra]+state_.gpr[rb],uint8_t(state_.gpr[rd]));
    else if(xo==54||xo==86||xo==278||xo==470||xo==598||xo==854||xo==982) { /* cache/sync/eieio no-op HLE */ }
    else if(xo==150) { /* stwcx. approximation */ mem_.write32(state_.gpr[ra]+state_.gpr[rb],state_.gpr[rd]); set_cr0(0); }
    else {char b[96];std::snprintf(b,sizeof b,"Unknown opcode 31/XO %u at %08X (%08X)",xo,pc,ins);error_=b;return StepResult::InvalidInstruction;}
    if(rc)set_cr0((xo==40||xo==266)?state_.gpr[rd]:state_.gpr[ra]);break;}
   default:{char b[96];std::snprintf(b,sizeof b,"Unknown opcode %u at %08X (%08X)",op,pc,ins);error_=b;return StepResult::InvalidInstruction;}
  }
  return StepResult::Ok;
 } catch(const std::exception& e){error_=e.what();return StepResult::MemoryFault;}
}
StepResult Cpu::run(uint32_t n){for(uint32_t i=0;i<n;i++){auto r=step();if(r!=StepResult::Ok)return r;}return StepResult::Ok;}
}
