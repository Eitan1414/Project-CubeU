#pragma once
#include "cubeu/memory.hpp"
#include <array>
#include <cstdint>
#include <string>

namespace cubeu {
struct CpuState {
    std::array<uint32_t,32> gpr{};
    std::array<double,32> fpr{};
    uint32_t pc=0, lr=0, ctr=0, cr=0, xer=0, msr=0, fpscr=0;
    uint64_t instructions=0, time_base=0;
};
enum class StepResult { Ok, Halted, InvalidInstruction, MemoryFault };
class Cpu {
public:
    explicit Cpu(Memory& memory);
    void reset(uint32_t entry);
    StepResult step();
    StepResult run(uint32_t max_instructions);
    const CpuState& state() const { return state_; }
    CpuState& state() { return state_; }
    const std::string& error() const { return error_; }
private:
    Memory& mem_; CpuState state_{}; bool halted_=false; std::string error_;
    static int32_t sign_extend(uint32_t value, unsigned bits);
    static uint32_t rotl32(uint32_t value, unsigned shift);
    static uint32_t mask32(unsigned mb, unsigned me);
    void set_cr_field(unsigned field, int32_t lhs, int32_t rhs, bool logical);
    void set_cr0(uint32_t value);
    uint32_t read_spr(uint32_t spr) const;
    void write_spr(uint32_t spr, uint32_t value);
};
}
