#pragma once
#include "cubeu/memory.hpp"
#include <cstdint>
#include <string>

namespace cubeu {
struct IsoInfo {
    std::string game_id;
    std::string title;
    std::uint64_t file_size = 0;
    std::uint32_t dol_offset = 0;
    std::uint32_t fst_offset = 0;
    std::uint32_t fst_size = 0;
    std::uint32_t fst_entries = 0;
    std::uint32_t fst_files = 0;
    std::uint32_t fst_directories = 0;
    std::uint32_t entry = 0;
    std::uint32_t sections_loaded = 0;
    std::uint32_t bytes_loaded = 0;
    bool header_valid = false;
    bool fst_valid = false;
    bool dol_loaded = false;
};

bool inspect_iso(const std::string& path, IsoInfo& info, std::string& error);
bool load_main_dol_from_iso(const std::string& path, Memory& memory, IsoInfo& info, std::string& error);
}
