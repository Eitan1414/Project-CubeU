#pragma once
#include "cubeu/memory.hpp"
#include <cstdint>
namespace cubeu { uint32_t install_demo_program(Memory& memory); }
