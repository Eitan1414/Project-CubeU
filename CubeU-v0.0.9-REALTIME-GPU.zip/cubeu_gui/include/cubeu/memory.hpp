#pragma once
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>
#include <deque>

namespace cubeu {
struct HardwareStats {
    uint64_t mmio_reads=0, mmio_writes=0, fifo_writes=0, dvd_commands=0;
    uint32_t last_mmio=0, last_fifo_word=0;
};

class Memory {
public:
    static constexpr uint32_t kBase = 0x80000000u;
    static constexpr std::size_t kSize = 24u * 1024u * 1024u;
    Memory();
    void clear();
    bool valid(uint32_t address, std::size_t bytes = 1) const;
    uint8_t read8(uint32_t address);
    uint16_t read16(uint32_t address);
    uint32_t read32(uint32_t address);
    uint64_t read64(uint32_t address);
    void write8(uint32_t address, uint8_t value);
    void write16(uint32_t address, uint16_t value);
    void write32(uint32_t address, uint32_t value);
    void write64(uint32_t address, uint64_t value);
    bool copy_in(uint32_t address, const uint8_t* data, std::size_t size);
    void tick(uint64_t cycles);
    const HardwareStats& hardware_stats() const { return stats_; }
    const std::string& hardware_note() const { return hardware_note_; }
    std::vector<uint8_t> take_fifo_bytes(std::size_t max_bytes);
private:
    std::vector<uint8_t> data_;
    std::vector<uint8_t> mmio_;
    HardwareStats stats_{};
    std::string hardware_note_="MMIO initialise";
    uint64_t ticks_=0;
    std::deque<uint8_t> fifo_bytes_;
    std::size_t offset(uint32_t address) const;
    static bool is_mmio(uint32_t address);
    static uint32_t mmio_offset(uint32_t address);
    uint8_t mmio_read8(uint32_t address);
    void mmio_write8(uint32_t address, uint8_t value);
};
}
