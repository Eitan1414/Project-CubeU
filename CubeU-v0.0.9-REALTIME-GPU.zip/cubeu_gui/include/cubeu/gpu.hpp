#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace cubeu {
class Memory;

struct GpuStats {
    uint64_t bytes_consumed = 0;
    uint64_t commands = 0;
    uint64_t bp_loads = 0;
    uint64_t primitives = 0;
    uint64_t frames = 0;
};

class SoftwareGpu {
public:
    static constexpr int kWidth = 320;
    static constexpr int kHeight = 240;

    explicit SoftwareGpu(Memory& memory);
    void reset();
    void process_fifo(std::size_t max_bytes = 64 * 1024);
    void present();
    const std::vector<uint32_t>& framebuffer() const { return front_; }
    const GpuStats& stats() const { return stats_; }
    const std::string& status() const { return status_; }

private:
    Memory& memory_;
    std::vector<uint32_t> front_;
    std::vector<uint32_t> back_;
    uint32_t bp_[256]{};
    GpuStats stats_{};
    std::string status_ = "GPU logiciel initialise";
    uint32_t frame_seed_ = 0;

    void clear(uint32_t color);
    void pixel(int x, int y, uint32_t color);
    void line(int x0, int y0, int x1, int y1, uint32_t color);
    void triangle(int x0, int y0, int x1, int y1, int x2, int y2, uint32_t color);
    void decode_command(const std::vector<uint8_t>& bytes, std::size_t& pos);
};
}
