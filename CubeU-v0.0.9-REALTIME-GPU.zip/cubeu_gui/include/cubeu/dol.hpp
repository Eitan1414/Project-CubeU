#pragma once
#include "cubeu/memory.hpp"
#include <cstdint>
#include <string>
namespace cubeu {
struct DolInfo { uint32_t entry=0; uint32_t sections_loaded=0; uint32_t bytes_loaded=0; };
bool load_dol(const std::string& path, Memory& memory, DolInfo& info, std::string& error);
}
