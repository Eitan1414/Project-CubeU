#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace cubeu {
struct GameEntry {
    std::string path;
    std::string title;
    std::string game_id;
    std::string region;
    std::uint64_t size_bytes = 0;
    bool header_valid = false;
};

class GameLibrary {
public:
    void scan(const std::string& root);
    const std::vector<GameEntry>& games() const { return games_; }
    const std::string& message() const { return message_; }
private:
    void scan_directory(const std::string& directory, int depth);
    void add_game(const std::string& path);
    std::vector<GameEntry> games_;
    std::string message_;
};
}
