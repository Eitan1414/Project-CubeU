# CubeU v0.0.9 — Realtime GPU

Prototype natif Wii U expérimental.

## Nouveautés
- boucle d'émulation temps réel, avec budget CPU par image ;
- démarrage direct du DOL principal depuis un ISO/GCM ;
- FIFO graphique Flipper mise en file et consommée par le GPU ;
- décodage expérimental des commandes BP et de débuts de primitives ;
- framebuffer logiciel 320×240 affiché sur TV et GamePad ;
- statistiques CPU, FIFO, primitives et images ;
- mapping GamePad et Wii U Pro conservé.

## Utilisation
Place les jeux dans `SD:/games/`. Ouvre la fiche d'un jeu puis appuie sur **Y** pour démarrer l'exécution temps réel. **B** arrête l'émulation et revient à la fiche.

## Limites importantes
Le GPU est un backend logiciel de validation. Il ne traduit pas encore correctement l'ensemble CP/XF/BP, les formats de sommets, textures, TEV, EFB/XFB, z-buffer et copies vidéo. L'image affichée matérialise l'activité FIFO et certaines commandes reconnues ; elle ne garantit pas encore le rendu réel du jeu. Le DSP, le DVD asynchrone, les interruptions complètes, la MMU et le JIT restent incomplets.
