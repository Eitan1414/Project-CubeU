#pragma once
#include <cstddef>
#include <cstdint>
#include <vector>

namespace cubeu {
class Memory {
public:
    static constexpr uint32_t kBase = 0x80000000u;
    static constexpr std::size_t kSize = 24u * 1024u * 1024u;
    Memory();
    void clear();
    bool valid(uint32_t address, std::size_t bytes = 1) const;
    uint8_t read8(uint32_t address) const;
    uint16_t read16(uint32_t address) const;
    uint32_t read32(uint32_t address) const;
    void write8(uint32_t address, uint8_t value);
    void write16(uint32_t address, uint16_t value);
    void write32(uint32_t address, uint32_t value);
    bool copy_in(uint32_t address, const uint8_t* data, std::size_t size);
private:
    std::vector<uint8_t> data_;
    std::size_t offset(uint32_t address) const;
};
}
