#pragma once
#include "cubeu/memory.hpp"
#include <array>
#include <cstdint>
#include <string>

namespace cubeu {
struct CpuState {
    std::array<uint32_t,32> gpr{};
    uint32_t pc=0, lr=0, ctr=0, cr=0, xer=0;
    uint64_t instructions=0;
};
enum class StepResult { Ok, Halted, InvalidInstruction, MemoryFault };
class Cpu {
public:
    explicit Cpu(Memory& memory);
    void reset(uint32_t entry);
    StepResult step();
    StepResult run(uint32_t max_instructions);
    const CpuState& state() const { return state_; }
    CpuState& state() { return state_; }
    const std::string& error() const { return error_; }
private:
    Memory& mem_; CpuState state_{}; bool halted_=false; std::string error_;
    static int32_t sign_extend(uint32_t value, unsigned bits);
    void set_cr0(uint32_t value);
};
}
