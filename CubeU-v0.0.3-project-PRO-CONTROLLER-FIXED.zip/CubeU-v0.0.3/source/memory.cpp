#include "cubeu/memory.hpp"
#include <algorithm>
#include <stdexcept>

namespace cubeu {
Memory::Memory() : data_(kSize, 0) {}
void Memory::clear() { std::fill(data_.begin(), data_.end(), 0); }
bool Memory::valid(uint32_t a, std::size_t n) const {
    if (a < kBase) return false;
    const uint64_t off = static_cast<uint64_t>(a) - kBase;
    return off + n <= data_.size();
}
std::size_t Memory::offset(uint32_t a) const {
    if (!valid(a)) throw std::out_of_range("GameCube address outside MEM1");
    return static_cast<std::size_t>(a - kBase);
}
uint8_t Memory::read8(uint32_t a) const { return data_[offset(a)]; }
uint16_t Memory::read16(uint32_t a) const {
    if (!valid(a,2)) throw std::out_of_range("read16");
    auto o=offset(a); return (uint16_t(data_[o])<<8)|data_[o+1];
}
uint32_t Memory::read32(uint32_t a) const {
    if (!valid(a,4)) throw std::out_of_range("read32");
    auto o=offset(a); return (uint32_t(data_[o])<<24)|(uint32_t(data_[o+1])<<16)|(uint32_t(data_[o+2])<<8)|data_[o+3];
}
void Memory::write8(uint32_t a,uint8_t v){ data_[offset(a)]=v; }
void Memory::write16(uint32_t a,uint16_t v){ if(!valid(a,2))throw std::out_of_range("write16"); auto o=offset(a);data_[o]=v>>8;data_[o+1]=v; }
void Memory::write32(uint32_t a,uint32_t v){ if(!valid(a,4))throw std::out_of_range("write32"); auto o=offset(a);data_[o]=v>>24;data_[o+1]=v>>16;data_[o+2]=v>>8;data_[o+3]=v; }
bool Memory::copy_in(uint32_t a,const uint8_t* d,std::size_t n){ if(!valid(a,n))return false; std::copy(d,d+n,data_.begin()+offset(a)); return true; }
}
