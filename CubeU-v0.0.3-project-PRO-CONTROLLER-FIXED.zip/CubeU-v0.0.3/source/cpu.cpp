#include "cubeu/cpu.hpp"
#include <cstdio>
#include <exception>

namespace cubeu {
Cpu::Cpu(Memory& m):mem_(m){}
void Cpu::reset(uint32_t e){state_={};state_.pc=e;halted_=false;error_.clear();}
int32_t Cpu::sign_extend(uint32_t v,unsigned b){const uint32_t m=1u<<(b-1);return static_cast<int32_t>((v^m)-m);}
void Cpu::set_cr0(uint32_t v){ uint32_t f=(static_cast<int32_t>(v)<0)?0x8:(v==0?0x2:0x4); state_.cr=(state_.cr&0x0FFFFFFFu)|(f<<28); }
StepResult Cpu::step(){
 if(halted_) return StepResult::Halted;
 try {
  const uint32_t pc=state_.pc, ins=mem_.read32(pc), op=ins>>26;
  state_.pc+=4; state_.instructions++;
  const uint32_t rd=(ins>>21)&31, ra=(ins>>16)&31, rb=(ins>>11)&31;
  switch(op){
   case 14:{ // addi
    int32_t imm=sign_extend(ins&0xFFFF,16); uint32_t base=ra?state_.gpr[ra]:0; state_.gpr[rd]=base+imm; break; }
   case 15:{ // addis
    int32_t imm=sign_extend(ins&0xFFFF,16)<<16; uint32_t base=ra?state_.gpr[ra]:0; state_.gpr[rd]=base+imm; break; }
   case 24: state_.gpr[ra]=state_.gpr[rd]|(ins&0xFFFF); break; // ori (RS=rd, RA=ra)
   case 25: state_.gpr[ra]=state_.gpr[rd]|((ins&0xFFFF)<<16); break;
   case 32:{int32_t d=sign_extend(ins&0xFFFF,16);state_.gpr[rd]=mem_.read32((ra?state_.gpr[ra]:0)+d);break;}
   case 34:{int32_t d=sign_extend(ins&0xFFFF,16);state_.gpr[rd]=mem_.read8((ra?state_.gpr[ra]:0)+d);break;}
   case 36:{int32_t d=sign_extend(ins&0xFFFF,16);mem_.write32((ra?state_.gpr[ra]:0)+d,state_.gpr[rd]);break;}
   case 38:{int32_t d=sign_extend(ins&0xFFFF,16);mem_.write8((ra?state_.gpr[ra]:0)+d,uint8_t(state_.gpr[rd]));break;}
   case 18:{ // b/bl
    int32_t li=sign_extend(ins&0x03FFFFFC,26); bool aa=ins&2, lk=ins&1; if(lk)state_.lr=state_.pc; state_.pc=aa?uint32_t(li):pc+li; break; }
   case 16:{ // bc
    int32_t bd=sign_extend(ins&0xFFFC,16); uint32_t bo=(ins>>21)&31, bi=(ins>>16)&31;
    bool ctr_ok=true, cond_ok=true;
    if(!(bo&4)){state_.ctr--;ctr_ok=((state_.ctr!=0)^bool(bo&2));}
    if(!(bo&16)){bool bit=(state_.cr>>(31-bi))&1;cond_ok=(bit==bool(bo&8));}
    if(ctr_ok&&cond_ok){if(ins&1)state_.lr=state_.pc;state_.pc=(ins&2)?uint32_t(bd):pc+bd;} break; }
   case 31:{
    uint32_t xo=(ins>>1)&0x3FF; bool rc=ins&1;
    if(xo==266){state_.gpr[rd]=state_.gpr[ra]+state_.gpr[rb];if(rc)set_cr0(state_.gpr[rd]);}
    else if(xo==444){state_.gpr[ra]=state_.gpr[rd]|state_.gpr[rb];if(rc)set_cr0(state_.gpr[ra]);}
    else if(xo==28){state_.gpr[ra]=state_.gpr[rd]&state_.gpr[rb];if(rc)set_cr0(state_.gpr[ra]);}
    else {char b[80];std::snprintf(b,sizeof b,"Unknown opcode 31/XO %u at %08X",xo,pc);error_=b;return StepResult::InvalidInstruction;} break; }
   case 19:{uint32_t xo=(ins>>1)&0x3FF;if(xo==16){state_.pc=state_.lr&~3u;if(state_.pc==0){halted_=true;return StepResult::Halted;}}else{error_="Unknown opcode 19";return StepResult::InvalidInstruction;}break;}
   default:{char b[80];std::snprintf(b,sizeof b,"Unknown opcode %u at %08X (%08X)",op,pc,ins);error_=b;return StepResult::InvalidInstruction;}
  }
  return StepResult::Ok;
 } catch(const std::exception& e){error_=e.what();return StepResult::MemoryFault;}
}
StepResult Cpu::run(uint32_t n){for(uint32_t i=0;i<n;i++){auto r=step();if(r!=StepResult::Ok)return r;}return StepResult::Ok;}
}
