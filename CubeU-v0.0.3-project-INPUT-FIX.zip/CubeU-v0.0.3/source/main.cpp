#include "cubeu/cpu.hpp"
#include "cubeu/demo.hpp"
#include "cubeu/dol.hpp"
#include "cubeu/library.hpp"
#include "cubeu/memory.hpp"
#include <cstdio>
#include <string>

#ifdef CUBEU_WIIU
#include <coreinit/thread.h>
#include <vpad/input.h>
#include <whb/log.h>
#include <whb/log_console.h>
#include <whb/proc.h>
#endif

using namespace cubeu;

#ifdef CUBEU_WIIU
namespace {
enum class Page { Home, Library, Details, Settings, About, Technical };

struct App {
    Memory memory;
    Cpu cpu;
    GameLibrary library;
    Page page = Page::Home;
    int selected = 0;
    int game_selected = 0;
    bool auto_scan = true;
    bool show_technical = false;
    std::string message = "Bienvenue dans CubeU.";

    App() : cpu(memory) {
        memory.clear();
        cpu.reset(install_demo_program(memory));
        scan_games();
    }

    void scan_games() {
        library.scan("fs:/vol/external01/games");
        game_selected = 0;
        message = library.message();
    }

    void run_self_test() {
        memory.clear();
        cpu.reset(install_demo_program(memory));
        const auto result = cpu.run(20);
        message = (result == StepResult::Halted && memory.read32(0x80000100) == 42)
            ? "Test moteur reussi : resultat 42."
            : "Le test moteur a rencontre une erreur.";
    }
};

void header(const char* title) {
    WHBLogPrintf("============================================\n");
    WHBLogPrintf("              CubeU v0.0.3\n");
    WHBLogPrintf("============================================\n");
    WHBLogPrintf("%s\n\n", title);
}

void footer(const char* controls) {
    WHBLogPrintf("\n--------------------------------------------\n");
    WHBLogPrintf("%s\n", controls);
}

void home(App& app) {
    static const char* items[] = { "Jeux", "Actualiser la bibliotheque", "Parametres", "A propos", "Quitter CubeU" };
    header("Menu principal");
    WHBLogPrintf("Jeux detectes : %u\n", static_cast<unsigned>(app.library.games().size()));
    WHBLogPrintf("Dossier       : SD:/games/\n\n");
    for (int i = 0; i < 5; ++i) WHBLogPrintf("%s %s\n", app.selected == i ? ">" : " ", items[i]);
    WHBLogPrintf("\n%s\n", app.message.c_str());
    footer("HAUT/BAS choisir   A valider   + quitter");
}

void library_page(App& app) {
    header("Bibliotheque de jeux");
    const auto& games = app.library.games();
    if (games.empty()) {
        WHBLogPrintf("Aucun jeu detecte.\n\n");
        WHBLogPrintf("Place tes fichiers ici :\n");
        WHBLogPrintf("  SD:/games/Nom du jeu/game.iso\n");
        WHBLogPrintf("ou\n");
        WHBLogPrintf("  SD:/games/Nom du jeu.gcm\n\n");
        WHBLogPrintf("Appuie sur X pour relancer la recherche.\n");
    } else {
        const int total = static_cast<int>(games.size());
        const int first = app.game_selected > 3 ? app.game_selected - 3 : 0;
        const int last = (first + 8 < total) ? first + 8 : total;
        for (int i = first; i < last; ++i) {
            WHBLogPrintf("%s %s\n", i == app.game_selected ? ">" : " ", games[i].title.c_str());
        }
        WHBLogPrintf("\n%u jeu(x) trouve(s).\n", static_cast<unsigned>(games.size()));
    }
    footer("HAUT/BAS choisir   A fiche   X actualiser   B retour");
}

void details(App& app) {
    header("Fiche du jeu");
    const auto& games = app.library.games();
    if (games.empty()) { WHBLogPrintf("Aucun jeu selectionne.\n"); footer("B retour"); return; }
    const auto& game = games[app.game_selected];
    WHBLogPrintf("Titre  : %s\n", game.title.c_str());
    WHBLogPrintf("ID     : %s\n", game.game_id.c_str());
    WHBLogPrintf("Region : %s\n", game.region.c_str());
    WHBLogPrintf("Taille : %.2f Gio\n", static_cast<double>(game.size_bytes) / 1073741824.0);
    WHBLogPrintf("Fichier: %s\n\n", game.path.c_str());
    WHBLogPrintf("> Lancer\n");
    WHBLogPrintf("  Retour\n\n");
    WHBLogPrintf("Le lancement des jeux n'est pas encore\n");
    WHBLogPrintf("implemente dans cette version.\n");
    footer("A information lancement   B retour");
}

void settings(App& app) {
    header("Parametres");
    WHBLogPrintf("> Recherche automatique : %s\n", app.auto_scan ? "ACTIVE" : "DESACTIVEE");
    WHBLogPrintf("  Informations techniques: %s\n\n", app.show_technical ? "VISIBLES" : "MASQUEES");
    WHBLogPrintf("A : activer/desactiver la recherche auto.\n");
    WHBLogPrintf("X : afficher la page technique.\n");
    footer("A modifier   X technique   B retour");
}

void about(App& app) {
    header("A propos");
    WHBLogPrintf("CubeU est un emulateur GameCube natif\n");
    WHBLogPrintf("experimental pour Wii U Aroma.\n\n");
    WHBLogPrintf("Cette version sait :\n");
    WHBLogPrintf("- rechercher des ISO et GCM sur la SD;\n");
    WHBLogPrintf("- lire le titre, l'ID et la region;\n");
    WHBLogPrintf("- afficher une bibliotheque simple;\n");
    WHBLogPrintf("- executer le premier test CPU interne.\n\n");
    WHBLogPrintf("Elle ne sait pas encore lancer un jeu,\n");
    WHBLogPrintf("afficher le GPU GameCube ou produire du son.\n\n");
    WHBLogPrintf("Y : lancer le test interne.\n");
    WHBLogPrintf("Resultat : %s\n", app.message.c_str());
    footer("Y test moteur   B retour");
}

void technical(App& app) {
    header("Informations techniques");
    const auto& s = app.cpu.state();
    WHBLogPrintf("MEM1 virtuelle : 24 Mio\n");
    WHBLogPrintf("PC             : %08X\n", s.pc);
    WHBLogPrintf("Instructions   : %llu\n", static_cast<unsigned long long>(s.instructions));
    WHBLogPrintf("Resultat test  : %u\n", app.memory.read32(0x80000100));
    WHBLogPrintf("Jeux indexes   : %u\n", static_cast<unsigned>(app.library.games().size()));
    footer("B retour");
}
}

int main(int argc, char** argv) {
    (void)argc; (void)argv;
    WHBProcInit();
    WHBLogConsoleInit();

    // Le mode TIGHT conserve les changements de boutons entre deux lectures.
    // C'est plus fiable sous Aroma que de dépendre d'un unique échantillon.
    VPADSetButtonProcMode(VPAD_CHAN_0, VPAD_BUTTON_PROC_MODE_TIGHT);

    App app;
    bool quit = false;
    uint32_t previous_hold = 0;

    while (WHBProcIsRunning() && !quit) {
        VPADStatus samples[16]{};
        VPADReadError error = VPAD_READ_NO_SAMPLES;
        const int32_t sample_count = VPADRead(VPAD_CHAN_0, samples, 16, &error);

        uint32_t pressed = 0;
        uint32_t current_hold = previous_hold;

        if (sample_count > 0 && error == VPAD_READ_SUCCESS) {
            // Les échantillons sont fournis du plus récent au plus ancien.
            current_hold = samples[0].hold;
            for (int32_t i = 0; i < sample_count; ++i) {
                pressed |= samples[i].trigger;
            }

            // Secours : calcule aussi le front montant à partir de hold.
            pressed |= current_hold & ~previous_hold;
            previous_hold = current_hold;
        }

        if (pressed & VPAD_BUTTON_PLUS) quit = true;
        if (app.page == Page::Home) {
            if (pressed & (VPAD_BUTTON_UP | VPAD_STICK_L_EMULATION_UP)) app.selected = (app.selected + 4) % 5;
            if (pressed & (VPAD_BUTTON_DOWN | VPAD_STICK_L_EMULATION_DOWN)) app.selected = (app.selected + 1) % 5;
            if (pressed & VPAD_BUTTON_A) {
                if (app.selected == 0) app.page = Page::Library;
                else if (app.selected == 1) app.scan_games();
                else if (app.selected == 2) app.page = Page::Settings;
                else if (app.selected == 3) app.page = Page::About;
                else quit = true;
            }
        } else if (app.page == Page::Library) {
            const int count = static_cast<int>(app.library.games().size());
            if (count > 0 && (pressed & (VPAD_BUTTON_UP | VPAD_STICK_L_EMULATION_UP))) app.game_selected = (app.game_selected + count - 1) % count;
            if (count > 0 && (pressed & (VPAD_BUTTON_DOWN | VPAD_STICK_L_EMULATION_DOWN))) app.game_selected = (app.game_selected + 1) % count;
            if (count > 0 && (pressed & VPAD_BUTTON_A)) app.page = Page::Details;
            if (pressed & VPAD_BUTTON_X) app.scan_games();
            if (pressed & VPAD_BUTTON_B) app.page = Page::Home;
        } else if (app.page == Page::Details) {
            if (pressed & VPAD_BUTTON_A) app.message = "Lancement indisponible dans CubeU v0.0.3.";
            if (pressed & VPAD_BUTTON_B) app.page = Page::Library;
        } else if (app.page == Page::Settings) {
            if (pressed & VPAD_BUTTON_A) app.auto_scan = !app.auto_scan;
            if (pressed & VPAD_BUTTON_X) app.page = Page::Technical;
            if (pressed & VPAD_BUTTON_B) app.page = Page::Home;
        } else if (app.page == Page::About) {
            if (pressed & VPAD_BUTTON_Y) app.run_self_test();
            if (pressed & VPAD_BUTTON_B) app.page = Page::Home;
        } else if (app.page == Page::Technical) {
            if (pressed & VPAD_BUTTON_B) app.page = Page::Settings;
        }
        WHBLogPrintf("\x1b[2J\x1b[H");
        if (app.page == Page::Home) home(app);
        else if (app.page == Page::Library) library_page(app);
        else if (app.page == Page::Details) details(app);
        else if (app.page == Page::Settings) settings(app);
        else if (app.page == Page::About) about(app);
        else technical(app);
        WHBLogConsoleDraw();
        OSSleepTicks(OSMillisecondsToTicks(16));
    }
    WHBLogConsoleFree(); WHBProcShutdown(); return 0;
}
#else
int main(int argc, char** argv) {
    Memory memory; Cpu cpu(memory); cpu.reset(install_demo_program(memory));
    const auto result = cpu.run(20);
    if (argc > 1) { GameLibrary library; library.scan(argv[1]); std::printf("%s\n", library.message().c_str()); }
    return result == StepResult::Halted && memory.read32(0x80000100) == 42 ? 0 : 1;
}
#endif
